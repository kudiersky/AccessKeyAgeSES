exports.params = {
    tableName : "AccessKeyAge", //name of table
    region: process.env.region, //region for DDB
    keyAgeLowerLimit: 70, //key age query lower limit.  

    
};